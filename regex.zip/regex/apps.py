from django.apps import AppConfig

class RegexConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'regex'
    verbose_name = 'Regex Analysis' 