import os
import re
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.contrib import messages
from django.conf import settings
import urllib.parse

# Ensure docx is imported if needed for docx scanning
# try:
#     from docx import Document
# except ImportError:
#     Document = None # Handle cases where python-docx is not installed

from .patterns import (
    sensitive_patterns,
    ALL_REGEX_PATTERNS_BACKEND,
    compile_regex_pattern,
    validate_regex_pattern,
    get_context_lines,
    should_scan_file
)

def is_safe_path(path):
    """Check if the given path is safe to access."""
    # Normalize the path
    normalized_path = os.path.normpath(path)
    # Get the absolute path
    abs_path = os.path.abspath(normalized_path)
    # Get the workspace root
    workspace_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    # Check if the path is within the workspace
    return abs_path.startswith(workspace_root)

# This function seems redundant with scan_file_with_regex, will keep it for now
# but it might be removed later if scan_file_with_regex can handle all cases.
def scan_file_for_sensitive_data(file_path, pattern):
    file_results = []
    if not is_safe_path(file_path):
        print(f"Skipping unsafe path in scan_file_for_sensitive_data: {file_path}")
        return file_results
    try:
        # Handle different file types
        if file_path.endswith('.docx'):
            try:
                from docx import Document
                doc = Document(file_path)
                content = "\n".join([para.text for para in doc.paragraphs])
            except ImportError:
                # Optionally log a warning here if python-docx is not installed
                print("python-docx not installed. Skipping .docx scan.")
                return file_results
        else:
            # For text files, try different encodings
            encodings = ['utf-8', 'latin-1', 'cp1254', 'iso-8859-9']
            content = None
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except (UnicodeDecodeError, FileNotFoundError): # Add FileNotFoundError check
                    continue
            
            if content is None:
                # Could not decode the file with common encodings or file not found
                 print(f"Could not read or decode file: {file_path}")
                 return file_results

        # Scan content for the pattern
        # Use the compiled pattern for efficiency if available, otherwise compile it
        compiled_pattern = compile_regex_pattern(pattern)
        if not compiled_pattern:
            return file_results # Skip if pattern is invalid

        matches = compiled_pattern.finditer(content, re.IGNORECASE) # Apply IGNORECASE as in original
        for match in matches:
            # Get some context around the match - using the helper from patterns.py
            line_number = content[:match.start()].count('\n') + 1
            
            # get_context_lines from patterns.py takes file_path and line_number
            # It reads the file again, which is inefficient. Let's pass the content and match indices.
            # I will adjust get_context_lines in patterns.py or create a local helper if needed.
            # For now, let's use the existing get_context_lines which re-reads the file.
            context_lines_list = get_context_lines(file_path, line_number, context=3)

            file_results.append({
                'file_path': file_path,
                'sensitive_type': 'Custom Pattern', # This function was likely for a single pattern type
                                                    # In the new regex_search_results_view, we map pattern to type.
                                                    # Let's keep 'Custom Pattern' for this function for now.
                'matched_data': match.group(),
                'line_number': line_number,
                'context': context_lines_list # Pass the list of line objects
            })
    except Exception as e:
        print(f"Error scanning file {file_path}: {e}") # Log the error
    return file_results

def convert_to_windows_path(path):
    """Convert WSL path to Windows path if needed"""
    if path.startswith('/mnt/'):
        # Convert /mnt/c/Users/... to C:/Users/...
        drive = path[5].upper()
        # Use os.path.join to correctly build the path
        return os.path.join(f"{drive}:\\", *path[7:].split('/'))
    return path

def scan_file_with_regex(file_path, pattern, scan_type='full'):
    """Scans a file for a given regex pattern. Reads partial content if scan_type is 'partial'."""
    file_results = []
    if not is_safe_path(file_path):
        print(f"Skipping unsafe path in scan_file_with_regex: {file_path}")
        return file_results
    try:
        # Convert path to Windows format if needed
        file_path_native = convert_to_windows_path(file_path)
        
        if not os.path.exists(file_path_native):
            return [{'error': f'Dosya bulunamadı: {file_path}'}]
            
        if not os.access(file_path_native, os.R_OK):
            return [{'error': f'Dosyaya erişim engellendi: {file_path}'}]

        # Handle different file types (same logic as scan_file_for_sensitive_data)
        if file_path_native.endswith('.docx'):
            try:
                from docx import Document
                doc = Document(file_path_native)
                content = "\n".join([para.text for para in doc.paragraphs])
            except ImportError:
                print("python-docx not installed. Skipping .docx scan.")
                return file_results
        else:
            # For text files, try different encodings and handle partial read
            encodings = ['utf-8', 'latin-1', 'cp1254', 'iso-8859-9']
            content = None
            for encoding in encodings:
                try:
                    with open(file_path_native, 'r', encoding=encoding) as f:
                        if scan_type == 'partial':
                            # Read first 100 lines
                            content_lines = []
                            for i in range(100):
                                line = f.readline()
                                if not line:
                                    break
                                content_lines.append(line)
                            content = "".join(content_lines)
                        else:
                            # Read entire file
                            content = f.read()
                    break
                except (UnicodeDecodeError, FileNotFoundError):
                    continue
            
            if content is None:
                 print(f"Could not read or decode file: {file_path}")
                 return file_results

        # Scan content for the provided regex pattern
        compiled_pattern = compile_regex_pattern(pattern) # Use compiled pattern
        if not compiled_pattern:
            return file_results # Skip if pattern is invalid

        matches = compiled_pattern.finditer(content)
        for match in matches:
            # Get some context around the match - using the helper from patterns.py
            # Note: get_context_lines reads the file again. For partial reads, 
            # this might give context from beyond the first 100 lines. 
            # A more robust solution would pass the already read content or 
            # modify get_context_lines to work with a list of lines.
            line_number = content[:match.start()].count('\n') + 1
            context_lines_list = get_context_lines(file_path_native, line_number, context=3) # Using the helper from patterns.py

            file_results.append({
                'file_path': file_path,
                'matched_data': match.group(),
                'line_number': line_number,
                'context': context_lines_list # Pass the list of line objects
            })
    except Exception as e:
        print(f"Error scanning file {file_path} with regex: {e}") # Log the error
    return file_results

def regex_search(request):
    return render(request, 'regex/regex_search.html')

def regex_search_results_view(request):
    # This view processes the search form submission
    if request.method == 'POST':
        # Get selected category from the form
        selected_category = request.POST.get('selected_category')
        # Get search path from the form
        search_path = request.POST.get('directory_path')
        # Get scan type from the form
        scan_type = request.POST.get('scan_type', 'full') # Default to full scan

        print(f"Regex Search started. Selected Category: {selected_category}, Path: {search_path}, Scan Type: {scan_type}")

        if not selected_category:
            messages.error(request, 'Lütfen bir arama kategorisi seçin.')
            return redirect('regex:regex_search')

        if not search_path:
            messages.error(request, 'Lütfen taranacak yolu belirtin.')
            return redirect('regex:regex_search')

        # Add safety check for path traversal and existence
        # Convert path to native format for os checks
        search_path_native = convert_to_windows_path(search_path)

        if not os.path.exists(search_path_native) or not is_safe_path(search_path_native):
             messages.error(request, f'Belirtilen yol bulunamadı veya erişim engellendi: {search_path}')
             return render(request, 'regex/regex_search_results.html', {'error_message': f'Belirtilen yol bulunamadı veya erişim engellendi: {search_path}'})

        # Build the combined regex pattern from the selected category's patterns
        patterns_to_compile = []
        pattern_type_mapping = {}

        # Look up the patterns for the selected category
        if selected_category in ALL_REGEX_PATTERNS_BACKEND:
            for pattern_info in ALL_REGEX_PATTERNS_BACKEND[selected_category]:
                pattern_str = pattern_info.get('pattern')
                subcategory = pattern_info.get('subcategory')
                if pattern_str and subcategory:
                    patterns_to_compile.append(pattern_str)
                    # Use subcategory as type for display
                    pattern_type_mapping[pattern_str] = subcategory
        else:
            messages.error(request, f'Geçersiz arama kategorisi: {selected_category}')
            return redirect('regex:regex_search')

        if not patterns_to_compile:
             messages.error(request, f'Seçilen kategori ({selected_category}) için geçerli regex patterni bulunamadı.')
             return redirect('regex:regex_search')

        # Combine all selected valid regex patterns into a single pattern
        combined_pattern_str = "|".join(patterns_to_compile)
        print(f"Combined regex pattern for category {selected_category}: {combined_pattern_str}")

        results = []
        processed_files_count = 0
        matched_files_count = 0

        try:
            files_to_scan = []
            # Determine if the path is a file or directory
            if os.path.isfile(search_path_native):
                 files_to_scan = [search_path]
            elif os.path.isdir(search_path_native):
                for root, _, files in os.walk(search_path_native):
                    for file in files:
                        file_path = os.path.join(root, file)
                        # Use should_scan_file from patterns.py and size limit
                        # Check against the original path string, not the native one for should_scan_file
                        if should_scan_file(file_path) and os.path.getsize(convert_to_windows_path(file_path)) < getattr(settings, 'MAX_SCAN_FILE_SIZE', 10*1024*1024):
                            # Add safety check within walk as well
                            if is_safe_path(file_path):
                                files_to_scan.append(file_path)
                            else:
                                print(f"Skipping unsafe path during walk: {file_path}")
                        else:
                            # Optionally log why a file is skipped
                            # Use the original path string for logging
                            print(f"Skipping file {file_path} (either should_scan_file is false or size exceeds limit).")
            else:
                messages.error(request, f'Geçersiz yol türü: {search_path}')
                return render(request, 'regex/regex_search_results.html', {'error_message': f'Geçersiz yol türü: {search_path}'})

            print(f"Found {len(files_to_scan)} files to scan.")

            # Scan files with the combined pattern and specified scan type
            for file_path in files_to_scan:
                processed_files_count += 1
                # is_safe_path already checked during file list generation, but good to double check
                if not is_safe_path(file_path):
                     print(f"Skipping scan of unsafe path: {file_path}")
                     continue

                file_scan_results = scan_file_with_regex(file_path, combined_pattern_str, scan_type=scan_type)

                # Count matches by pattern type for this file
                file_pattern_counts = {}
                file_has_matches = False
                for match_result in file_scan_results:
                    # Find which pattern type this match belongs to
                    # Iterate through original patterns to find the match
                    matching_pattern_str = None
                    try:
                        # A more efficient way: modify scan_file_with_regex to return pattern str with match
                        # For now, re-scan the matched data with original patterns
                        for original_pattern_str in patterns_to_compile:
                            try:
                                temp_compiled_original_pattern = compile_regex_pattern(original_pattern_str)
                                if temp_compiled_original_pattern and temp_compiled_original_pattern.search(match_result['matched_data']):
                                    matching_pattern_str = original_pattern_str
                                    break
                            except Exception as compile_err:
                                print(f"Error compiling original pattern for counting {original_pattern_str}: {compile_err}")
                                continue
                    except Exception as e:
                         print(f"Error finding matching pattern for counting: {e}")

                    if matching_pattern_str and matching_pattern_str in pattern_type_mapping:
                        pattern_type = pattern_type_mapping[matching_pattern_str]
                        file_pattern_counts[pattern_type] = file_pattern_counts.get(pattern_type, 0) + 1
                        file_has_matches = True

                if file_has_matches:
                    matched_files_count += 1
                    results.append({
                        'file_path': file_path,
                        'file_name': os.path.basename(file_path),
                        'directory_path': os.path.dirname(file_path),
                        'pattern_counts': file_pattern_counts,
                        # Include the raw match results for detail view if needed later
                        'matches': file_scan_results
                    })

        except Exception as e:
            print(f"Error during regex search: {e}") # Log the error
            messages.error(request, f'Arama sırasında bir hata oluştu: {e}')
            return render(request, 'regex/regex_search_results.html', {'error_message': f'Arama sırasında bir hata oluştu: {e}'})
            
        print(f"Scan complete. Processed {processed_files_count} files, found matches in {matched_files_count} files, total results: {len(results)}.")

        return render(request, 'regex/regex_search_results.html', {
            'results': results,
            'search_path': search_path,
            'processed_files_count': processed_files_count,
            'matched_files_count': matched_files_count,
        })
    else:
        # If it's not a POST request, redirect to the search page
        return redirect('regex:regex_search')

def regex_search_detail_view(request, file_path):
    """This view displays detailed matches for a single file."""
    # The file_path here is the URL-encoded path passed in the URL
    decoded_file_path = urllib.parse.unquote(file_path)

    # Convert path to native format
    file_path_native = convert_to_windows_path(decoded_file_path)

    # Add safety check for path traversal and existence
    if not os.path.exists(file_path_native) or not is_safe_path(file_path_native) or not os.path.isfile(file_path_native):
        messages.error(request, f'Dosya bulunamadı veya erişim engellendi: {decoded_file_path}')
        # Redirect back to results or search page
        # For simplicity, redirect to search for now
        return redirect('regex:regex_search')

    all_matches = []
    try:
        # Read file content once
        file_content = ""
        encodings = ['utf-8', 'latin-1', 'cp1254', 'iso-8859-9']
        content = None
        for encoding in encodings:
            try:
                with open(file_path_native, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except (UnicodeDecodeError, FileNotFoundError):
                continue
        
        if content is None:
            messages.error(request, f'Dosya içeriği okunamadı: {decoded_file_path}')
            return render(request, 'regex/regex_search_detail.html', {'error_message': f'Dosya içeriği okunamadı: {decoded_file_path}'})

        file_content = content
        lines = file_content.splitlines()

        # Re-scan the file with ALL known regex patterns to find all matches in this file
        # This is a temporary solution. A better way is to pass specific match data.
        for category, patterns_list in ALL_REGEX_PATTERNS_BACKEND.items():
            for pattern_info in patterns_list:
                pattern_str = pattern_info.get('pattern')
                subcategory = pattern_info.get('subcategory', 'Belirsiz Desen')

                if pattern_str:
                    compiled_pattern = compile_regex_pattern(pattern_str)
                    if compiled_pattern:
                        matches = compiled_pattern.finditer(file_content)
                        for match in matches:
                            line_number = file_content[:match.start()].count('\n') + 1
                            # Get context lines using the helper
                            context_lines_list = get_context_lines(file_path_native, line_number, context=3)

                            all_matches.append({
                                'pattern_type': subcategory,
                                'matched_data': match.group(),
                                'line_number': line_number,
                                'context': context_lines_list
                            })

    except Exception as e:
        print(f"Error during detail view scan of {decoded_file_path}: {e}")
        messages.error(request, f'Dosya detayları işlenirken bir hata oluştu: {e}')
        return render(request, 'regex/regex_search_detail.html', {'error_message': f'Dosya detayları işlenirken bir hata oluştu: {e}'})

    # Sort matches by line number
    all_matches.sort(key=lambda x: x['line_number'])

    return render(request, 'regex/regex_search_detail.html', {
        'file_path': decoded_file_path,
        'matches': all_matches,
        'lines': [{'line_number': i + 1, 'text': line} for i, line in enumerate(lines)] # Pass all lines for context display
    })

def regex_search_detail(request):
    # This view is likely not needed if using regex_search_detail_view with file_path in URL
    # Keeping it for now based on previous code structure
    pass

def api_get_regex_patterns(request):
    """API endpoint to return all regex patterns in JSON format."""
    # Return ALL_REGEX_PATTERNS_BACKEND directly
    return JsonResponse(ALL_REGEX_PATTERNS_BACKEND)

# Helper function to scan directory recursively (if needed separately)
# def scan_directory_recursive(directory_path, pattern):
#     all_results = []
#     if not os.path.isdir(directory_path):
#         return all_results # Not a directory

#     for root, _, files in os.walk(directory_path):
#         for file in files:
#             file_path = os.path.join(root, file)
#             if should_scan_file(file_path) and is_safe_path(file_path):
#                 file_results = scan_file_with_regex(file_path, pattern) # Use the new scan_file_with_regex
#                 all_results.extend(file_results)
#     return all_results

# Helper function to scan a single file (if needed separately)
# def scan_single_file(file_path, pattern):
#      if should_scan_file(file_path) and is_safe_path(file_path):
#          return scan_file_with_regex(file_path, pattern) # Use the new scan_file_with_regex
#      return []
